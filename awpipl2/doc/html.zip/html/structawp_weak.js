var structawp_weak =
[
    [ "alfa", "structawp_weak.html#a8ecbe72863fa4bb064705c086230eac7", null ],
    [ "bins", "structawp_weak.html#a87ff0ad38ad2839fa6352ef1893e6ab5", null ],
    [ "h", "structawp_weak.html#a00db6ee76bc5dd0aebbc4176dae050a4", null ],
    [ "numBins", "structawp_weak.html#a515b0aa3c5977d9629890d0b6ae90564", null ],
    [ "w", "structawp_weak.html#acf474af77e135c7d3a0463b9e61f8a5b", null ],
    [ "x", "structawp_weak.html#a152b90243149e20766544b158efd5946", null ],
    [ "y", "structawp_weak.html#aa33cb9236911b03594f29702ff096703", null ]
];