var awpcommon_8c =
[
    [ "awpCheckImage", "group__commongroup.html#ga7d911d9f379047ad5806117d486f031d", null ],
    [ "awpCheckRect", "group__commongroup.html#ga91451c6b523bc724a10e0982b0c3eafa", null ],
    [ "awpCreateGrayImage", "group__commongroup.html#ga53c71d52f7a3154e5d0438854ca8ef2f", null ],
    [ "awpCreateImage", "group__commongroup.html#ga1f59daab5b67e2c09d0c4970a157ad13", null ],
    [ "awpCreateMultiImage", "group__commongroup.html#ga677ea4863932269ec5f6563a2be4156a", null ],
    [ "awpGetImageHeaderSize", "group__commongroup.html#gace143c493378d2a91fbd3840521aea18", null ],
    [ "awpGetImagePixelType", "group__commongroup.html#ga82f4bca2acc56a58b8c1c340c08fffe1", null ],
    [ "awpGetImageSize", "group__commongroup.html#ga081e0bf7ef1efa22bd83b9fb3dbe1bbf", null ],
    [ "awpGetVersion", "group__commongroup.html#gaa78bba85ad015ff8dce2db65b2230879", null ],
    [ "awpMinMax", "group__arifgroup.html#ga50b513f4dc64406690dadcb3fbfaca83", null ],
    [ "awpRectInImage", "group__commongroup.html#ga4f79242120fc832deac974fb65abc8e6", null ],
    [ "awpReleaseImage", "group__commongroup.html#ga6d2deb021b547aa5ff2c45531394651c", null ]
];