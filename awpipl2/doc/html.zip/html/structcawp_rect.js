var structcawp_rect =
[
    [ "c", "structcawp_rect.html#a8be3a87cc11b07696d3d464b57387f0d", null ],
    [ "r", "structcawp_rect.html#a17da818e4c99f7e0e44ea0e714e8effe", null ]
];