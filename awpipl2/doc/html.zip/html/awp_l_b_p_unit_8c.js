var awp_l_b_p_unit_8c =
[
    [ "_awp_neighborhood_", "awp_l_b_p_unit_8c.html#ac844c3e70b2693e482c6c3e5023d5b04", null ],
    [ "_awp_neighborhood_interpolation_", "awp_l_b_p_unit_8c.html#aec535e3dcfdc45cd3995dc9df542baa5", null ],
    [ "awpLBPCode", "group__awplbbgroup.html#ga273089f1ca98f8407c7d3ca4e4813dc7", null ],
    [ "awpLBPDescriptor", "group__awplbbgroup.html#ga64743a44bcd54462cd48486620e0c5cb", null ],
    [ "awpLBPGridDescriptor", "group__awplbbgroup.html#gaae157becf97eb0b510167305f94f4f4f", null ],
    [ "awpLPBPoints", "group__awplbbgroup.html#gaf51a5d841087238303a64a14d7b1947f", null ],
    [ "awpLPBSPoints", "group__awplbbgroup.html#ga93d941e9e02499270cf790c4ed1e6cd1", null ],
    [ "c_cos45", "awp_l_b_p_unit_8c.html#ac90f48b8abe323be8979b01b0ddff834", null ],
    [ "c_LBPBitShift", "awp_l_b_p_unit_8c.html#a3fa91c7e54f02606fcb3432db07d0543", null ],
    [ "c_LBPEpsSize", "awp_l_b_p_unit_8c.html#a2d0d36cb91783a89af3a91a6ebbd0d18", null ],
    [ "c_LBPUniform", "awp_l_b_p_unit_8c.html#aae919da04e0baaa7a98a025e117dc726", null ],
    [ "c_ScaleBase", "awp_l_b_p_unit_8c.html#ad6a02acc9a3f294169d18c57e8780b45", null ],
    [ "c_sin45", "awp_l_b_p_unit_8c.html#af692b451e7cac8273085eca0fa79053a", null ]
];