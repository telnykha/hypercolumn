var structawp_rect =
[
    [ "bottom", "structawp_rect.html#aa44ae661c06fe6fe9ab4817d046ca9bc", null ],
    [ "left", "structawp_rect.html#ab976ec6e4309c9785d1da823c165f185", null ],
    [ "right", "structawp_rect.html#a8aa98195f3b4eead522fd49c3fef2c16", null ],
    [ "top", "structawp_rect.html#a6123ab49903fa86f1f9c0d7a742717a6", null ]
];