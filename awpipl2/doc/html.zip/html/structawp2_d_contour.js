var structawp2_d_contour =
[
    [ "Direction", "structawp2_d_contour.html#afb51eba851fb3c44268a9e2b10dfc577", null ],
    [ "NumPoints", "structawp2_d_contour.html#a7848403591387b703285a38ecc77af79", null ],
    [ "Points", "structawp2_d_contour.html#a6826bab75e3b45109c8c257d229bb57b", null ]
];