var structcawp_detect_item =
[
    [ "c", "structcawp_detect_item.html#a8be3a87cc11b07696d3d464b57387f0d", null ],
    [ "r", "structcawp_detect_item.html#a2a69951e2f2a601ea66fac58ca54551e", null ]
];