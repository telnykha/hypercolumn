var awp_scanners_unit_8c =
[
    [ "cawpDetectItem", "structcawp_detect_item.html", "structcawp_detect_item" ],
    [ "_awpAllScanner", "awp_scanners_unit_8c.html#a9dcd43f01bf9b823bba776d6fb1f336c", null ],
    [ "_awpCameraScanner", "awp_scanners_unit_8c.html#adcb3fbbf7840b937c7df0e9d19c216b6", null ],
    [ "_awpCameraScanner1", "awp_scanners_unit_8c.html#ae92040f4b9c76840164972737ad0dc02", null ],
    [ "_awpItemsOverlap", "awp_scanners_unit_8c.html#a032ba05b1eceb45c3ab4601361233cb6", null ],
    [ "_awpScaleScanner", "awp_scanners_unit_8c.html#ae19847f6088ea2b5088904451945a31d", null ],
    [ "awpClusterFound", "group__detectorgroup.html#gac6ee5e85a1f30e2fe3b79c7a8a8a2556", null ],
    [ "awpExteractFound", "group__detectorgroup.html#ga9f9d42771a64ef69a6f95e3ffc711fc5", null ],
    [ "awpScanImage", "group__detectorgroup.html#ga6864a8dae799d27a670e3ae50163de47", null ]
];