var structawp2_d_point =
[
    [ "X", "structawp2_d_point.html#a8e402c31858630c1da194c0f13b03c08", null ],
    [ "Y", "structawp2_d_point.html#a313dd1a4e73b2ba492b40b043f3d6c22", null ]
];