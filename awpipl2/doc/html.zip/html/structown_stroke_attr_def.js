var structown_stroke_attr_def =
[
    [ "l_attr", "structown_stroke_attr_def.html#a43b3ca62d77cd90b964f7659194c1134", null ],
    [ "l_index", "structown_stroke_attr_def.html#a0288f928c8bd85cd4a2f373c39b48d88", null ],
    [ "r_attr", "structown_stroke_attr_def.html#a432c05fafa5adc7031aae70a126c99e1", null ],
    [ "r_index", "structown_stroke_attr_def.html#ad396cf82e53a0fee056abdd1b710603a", null ],
    [ "xl", "structown_stroke_attr_def.html#af33b9f0dda032613c40ebc1a160455e5", null ],
    [ "xr", "structown_stroke_attr_def.html#a1d16e691065d8e66c69cff11d09a9369", null ],
    [ "y", "structown_stroke_attr_def.html#ab8cde0d6d54371ee5ddde947b1ad47c2", null ]
];