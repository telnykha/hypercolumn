var awpgeometry_8c =
[
    [ "awpFlip", "group__geometricgroup.html#gabd7515e8ac866079ce78f1362e36903b", null ],
    [ "awpRescale", "group__geometricgroup.html#ga5e6611aa6e816652cdbcc0520c3e39a0", null ],
    [ "awpResize", "group__geometricgroup.html#gabf5fbf2c32cbedf16d0799d972fa0817", null ],
    [ "awpResizeBicubic2x2", "awpgeometry_8c.html#a310ead2a7fa6ee7ac34145384ac68327", null ],
    [ "awpResizeBicubic4x4", "awpgeometry_8c.html#a4319582fc033cfb558bf7cede6a3c91b", null ],
    [ "awpResizeBilinear", "group__geometricgroup.html#gaec327adef0c943ebd200a2b2a5e7118c", null ],
    [ "awpResizeNip", "group__geometricgroup.html#ga71c25e10bc2a75441bd088810603f337", null ],
    [ "awpResizePiecewiseCubic", "awpgeometry_8c.html#a0fe6b0581e9d9e8c89749809a5c55bdd", null ],
    [ "awpRotate", "group__geometricgroup.html#ga75e2951d6652599c0811e58bb2d2637b", null ],
    [ "awpRotate2", "group__geometricgroup.html#ga2f951a690c1e7ba57e3577f1c1fb1bc4", null ],
    [ "awpRotateBilinear", "group__geometricgroup.html#gab5e3e4a7f7dd5dbec4e0ebd05813f93f", null ],
    [ "awpRotateCenter", "group__geometricgroup.html#gac33098101f01e7efea5b398479b9c673", null ],
    [ "awpRotateCenter2", "group__geometricgroup.html#gad3706ae144760f745f9f1c1a2af48c6a", null ]
];