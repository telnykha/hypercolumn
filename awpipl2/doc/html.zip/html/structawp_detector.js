var structawp_detector =
[
    [ "height", "structawp_detector.html#a9673081bad2219b9dcc5aef487c0d579", null ],
    [ "nStages", "structawp_detector.html#aca4fdd4bcc3799930032658aad1b6097", null ],
    [ "pStrongs", "structawp_detector.html#af0beec86bd78700ea4b41587234c33ca", null ],
    [ "type", "structawp_detector.html#ac32238f9c92e69700ff2c2a0b2d92d7e", null ],
    [ "width", "structawp_detector.html#a105bcae4ffe7d9cfdb26119d2aeb263f", null ]
];