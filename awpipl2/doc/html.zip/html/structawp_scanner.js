var structawp_scanner =
[
    [ "baseHeight", "structawp_scanner.html#a5ce6f94a4e7736b882046edbc8b1b3b9", null ],
    [ "baseWidth", "structawp_scanner.html#a035207a9a8202e4cccceb5ad4f9358f9", null ],
    [ "camera", "structawp_scanner.html#ac30c696c44c029aea7803f1db3cc901f", null ],
    [ "maxDistance", "structawp_scanner.html#ac2eee20df984f3d3861ca401ab96d953", null ],
    [ "maxHeight", "structawp_scanner.html#a59429c1f390d223421dd9331e5309772", null ],
    [ "maxScale", "structawp_scanner.html#abbd17c8f858f9882adccef868e14db01", null ],
    [ "maxShift", "structawp_scanner.html#a6e3779beb14c78cb8e253e3d87a9a5da", null ],
    [ "minDistance", "structawp_scanner.html#ac2f3c349317acc84590c432284ee1991", null ],
    [ "minHeight", "structawp_scanner.html#a682bd168298025205bf19cd95dfeba97", null ],
    [ "minScale", "structawp_scanner.html#a3c21058200f7a329f88979d27f199868", null ],
    [ "minShift", "structawp_scanner.html#a196252099ce2bfa27fb84e705a6abeec", null ],
    [ "scaleStep", "structawp_scanner.html#a6f35b366f6c4584159dc45422902d5a7", null ],
    [ "scannerType", "structawp_scanner.html#ae863eabbc239e5178104fd6dc5c699e6", null ],
    [ "stepDistance", "structawp_scanner.html#a574a648eb2639e5a644b20e2a6a435cd", null ],
    [ "stepGranularity", "structawp_scanner.html#a84c0d042626c96fd5457ec6512ea94bd", null ],
    [ "stepHeight", "structawp_scanner.html#a1832cff847e32b6466c3a2ab53aefb8d", null ],
    [ "stepShift", "structawp_scanner.html#a765b64c4299a7e2d65e90439e95d8137", null ],
    [ "xStep", "structawp_scanner.html#a1d49a83c1ff062638e45660d0e49eb35", null ],
    [ "yStep", "structawp_scanner.html#a0fe46ac1cc5fe56db7befdb3426ab0b1", null ]
];