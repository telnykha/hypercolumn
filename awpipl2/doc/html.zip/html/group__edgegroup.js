var group__edgegroup =
[
    [ "awpEdgeSobel", "group__edgegroup.html#ga1a7c269547202d24f189f74b25bf8e70", null ],
    [ "awpEdgeSobel1", "group__edgegroup.html#gac502740fca743bb323f0c43064a1cecb", null ]
];