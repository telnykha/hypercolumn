var structtagawp_r_g_b_color =
[
    [ "bBlue", "structtagawp_r_g_b_color.html#aabc4e03bafc1a959db6912e4fb7e4450", null ],
    [ "bGreen", "structtagawp_r_g_b_color.html#a9cbb3177c39dadc446e08b8137605a59", null ],
    [ "bRed", "structtagawp_r_g_b_color.html#a7361ba4cd819bc0902925a6e57dee451", null ]
];