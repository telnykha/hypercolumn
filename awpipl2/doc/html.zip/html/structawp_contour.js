var structawp_contour =
[
    [ "Direction", "structawp_contour.html#afb51eba851fb3c44268a9e2b10dfc577", null ],
    [ "NumPoints", "structawp_contour.html#a7848403591387b703285a38ecc77af79", null ],
    [ "Points", "structawp_contour.html#aa350bec96a232902cf57c2212aa0c98c", null ]
];