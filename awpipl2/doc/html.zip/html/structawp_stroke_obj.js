var structawp_stroke_obj =
[
    [ "Num", "structawp_stroke_obj.html#aea0de675fce48032419164e1ee46a2f3", null ],
    [ "strokes", "structawp_stroke_obj.html#a3de64ad7b72b5bba78f0e77c6fff9b1b", null ]
];