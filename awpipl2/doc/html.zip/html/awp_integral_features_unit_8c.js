var awp_integral_features_unit_8c =
[
    [ "awp2BitLBP", "awp_integral_features_unit_8c.html#a3c2b53cb6750b98123255de13d3ad71b", null ],
    [ "awp4BitLBP", "awp_integral_features_unit_8c.html#a33f8b9c1a4c3ee59bc45f2c606d597d1", null ],
    [ "awpIntegralGrid", "awp_integral_features_unit_8c.html#aa470c64f4e51b3186b1431faa03df792", null ]
];