var __awp_h_s_l_8h =
[
    [ "_awpHLStoRGB", "__awp_h_s_l_8h.html#aa50d562da8666c7d9cc7523e16c80f3f", null ],
    [ "_awpRGBtoHSL", "__awp_h_s_l_8h.html#a1c941b84366e3fb7742b3c5cf5a92a8d", null ]
];