var structawp2_d_line_segment =
[
    [ "end", "structawp2_d_line_segment.html#a7a1bd717ba005d9dda5b405e74e2bddd", null ],
    [ "strat", "structawp2_d_line_segment.html#a25c9c57721b69b4404dc88a14a56f119", null ]
];