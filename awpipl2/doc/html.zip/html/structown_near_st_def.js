var structown_near_st_def =
[
    [ "index", "structown_near_st_def.html#a981860a2d39552e4a7fcb3887d87d90b", null ],
    [ "index1", "structown_near_st_def.html#ac7b0dbe22c5dc2a9f18cf6a709eb63d0", null ],
    [ "IsFound", "structown_near_st_def.html#ac84828ce8e74aa9cdb49453a27473f5c", null ],
    [ "IsLeft", "structown_near_st_def.html#a0570fad9fbb2ecbb601bf1affd4d5d17", null ],
    [ "x", "structown_near_st_def.html#ad0760d5cf6c0e71704fdc329f4bfea42", null ],
    [ "x1", "structown_near_st_def.html#a4ef005c6372b37f1d808aaf80f2ad03e", null ]
];