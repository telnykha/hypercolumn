var structawp_detect_item =
[
    [ "Distance", "structawp_detect_item.html#a828c3d7d2ada5e9db13c3b6f6503e9eb", null ],
    [ "hasObject", "structawp_detect_item.html#a31f8a785bbf938abc13e2e9951894d62", null ],
    [ "Height", "structawp_detect_item.html#a33cbef422fc20a12b1f0af2499940ca9", null ],
    [ "overlap", "structawp_detect_item.html#a16a6938451038fd9a31de8f1313150b9", null ],
    [ "rect", "structawp_detect_item.html#ab98e6b08edc24be5b1970dee24fe4e43", null ],
    [ "Shift", "structawp_detect_item.html#ab1667870188ddcdfd1b4a46da807aa30", null ],
    [ "Width", "structawp_detect_item.html#a7176c436340c7f271d58745a08f133e5", null ]
];