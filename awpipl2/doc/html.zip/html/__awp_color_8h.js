var __awp_color_8h =
[
    [ "_awp_hsl_to_rgb", "__awp_color_8h.html#a607165f484f92713530a69d0714bb959", null ],
    [ "_awp_hsv_to_rgb", "__awp_color_8h.html#a1c965cb3bc617ddcb0c4d8633a9a99f3", null ],
    [ "_awp_lab_to_rgb", "__awp_color_8h.html#ab5225dbc12d298dac83e534109cdb106", null ],
    [ "_awp_lab_to_xyz", "__awp_color_8h.html#af1acf4b9ff7ec71eae0908a411ef475c", null ],
    [ "_awp_rgb_to_hsl", "__awp_color_8h.html#a3419662688e38450048d3f817105c321", null ],
    [ "_awp_rgb_to_hsv", "__awp_color_8h.html#a680b6860b29480394e9408db19150140", null ],
    [ "_awp_rgb_to_lab", "__awp_color_8h.html#a8efed86d0ac75b9874e9c10670bc10c9", null ],
    [ "_awp_rgb_to_xyz", "__awp_color_8h.html#a773d75519c0c8ab251cd4ac6d7cc1a64", null ],
    [ "_awp_xyz_to_lab", "__awp_color_8h.html#ac170106df1adc4bd6e3799bb4906c35f", null ],
    [ "_awp_xyz_to_rgb", "__awp_color_8h.html#a40f76fa7310a39e5a0d95f9398551ea7", null ]
];