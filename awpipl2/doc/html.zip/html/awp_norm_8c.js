var awp_norm_8c =
[
    [ "_AWP_NORM_L1", "awp_norm_8c.html#a303c6428f4bf201d8190df841242764a", null ],
    [ "_AWP_NORM_L2", "awp_norm_8c.html#a08d048c5f8cd5a7e0e6e7432fd9d9336", null ],
    [ "_AWP_NORMALIZE_", "awp_norm_8c.html#aeb3319e701419ecbec75443f57eba752", null ],
    [ "awpNorm", "group__convertgroup.html#ga88627d08f24e2086a728deff557cd0ef", null ],
    [ "awpNormalize", "group__convertgroup.html#ga8ab1f44f6d6dc75b437ead02d528be71", null ]
];