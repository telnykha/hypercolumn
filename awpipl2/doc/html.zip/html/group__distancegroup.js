var group__distancegroup =
[
    [ "awpDistance", "group__distancegroup.html#ga054a41d68e8eeb8971b9290b66a182cf", null ],
    [ "awpDistancePoints", "group__distancegroup.html#ga31b8ebab312f0078f04ff41c980f2fbf", null ],
    [ "awpGridDistance", "group__distancegroup.html#ga4776749b85063b98f84eb821fa9a2389", null ]
];