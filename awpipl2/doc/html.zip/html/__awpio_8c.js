var __awpio_8c =
[
    [ "tagOldAwpColor", "structtag_old_awp_color.html", "structtag_old_awp_color" ],
    [ "OldAwpColor", "__awpio_8c.html#aa20ad2bf0cea770f7a5207ce24bcc441", null ],
    [ "_awpGetFileExt", "__awpio_8c.html#aedc40db01d8dfabb71ef4f196c972572", null ],
    [ "_awpLoadAWPImage", "__awpio_8c.html#adf5236d868acbc6c05b31cec578501dc", null ],
    [ "_awpLoadAWPImageV1", "__awpio_8c.html#a4d672c56584d6c782c0831f9ff0c1ca8", null ],
    [ "_awpSaveAWPImage", "__awpio_8c.html#afd116fff3fcdc3a8032fe6fa58c853be", null ]
];