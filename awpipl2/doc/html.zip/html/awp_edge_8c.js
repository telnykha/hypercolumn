var awp_edge_8c =
[
    [ "_CONVERT_SOBEL_ANGLE_", "awp_edge_8c.html#a5bb2dbb4fcaf349f6c37e97eb4b7a123", null ],
    [ "_COPY_SOBEL_RESULT_ANGLE_", "awp_edge_8c.html#a609711f717227782aabd0aae52d9be58", null ],
    [ "awpCanny", "awp_edge_8c.html#a2c121aa8ece58c0f4ce21f1ac42e5575", null ],
    [ "awpEdgeSobel", "group__edgegroup.html#ga1a7c269547202d24f189f74b25bf8e70", null ],
    [ "awpEdgeSobel1", "group__edgegroup.html#gac502740fca743bb323f0c43064a1cecb", null ],
    [ "awpFeatures", "awp_edge_8c.html#ac4e06fefb668a992e57408a710d035d1", null ],
    [ "awpFeaturesV2", "awp_edge_8c.html#a4045094cfe0ecd41ddf67b8855b568f2", null ],
    [ "awpLocalMax", "awp_edge_8c.html#aac0ae38504cf27dbf00e121297e776cb", null ],
    [ "awpLocalMin", "awp_edge_8c.html#ad6278724a0a3f311161a2a4e42be0d9f", null ]
];