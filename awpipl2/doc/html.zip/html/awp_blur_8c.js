var awp_blur_8c =
[
    [ "awpCreateGaussKernel", "awp_blur_8c.html#a54f122c07e7afa45c677ca463e3cf224", null ],
    [ "awpGaussianBlur", "group__arifgroup.html#gaea949ea5abb3c41086c01abbf35c73a0", null ]
];