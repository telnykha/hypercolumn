var awp_detector_unit_8c =
[
    [ "cawpRect", "structcawp_rect.html", "structcawp_rect" ],
    [ "_awpClusterRects", "awp_detector_unit_8c.html#a0465b20d94dc4b99abba3917953b7ed8", null ],
    [ "_awpInitGLBPCascade", "awp_detector_unit_8c.html#a29dc31829a455c331d409ee4c25bcb5e", null ],
    [ "_awpInitGMCTCascade", "awp_detector_unit_8c.html#ace867d7a612c6a7e913abe6a0a1e70a2", null ],
    [ "_awpInitLLBPCascade", "awp_detector_unit_8c.html#aa523b36b319d36ca36e0c9793b03b555", null ],
    [ "_awpInitLMCTCascade", "awp_detector_unit_8c.html#a4b3b3c066219b6de23e5d2828c285a4c", null ],
    [ "_awpRectsOverlap", "awp_detector_unit_8c.html#a145da71f6edb6785ace65a7aa79899bc", null ],
    [ "awpCreateCascade", "group__detectorgroup.html#ga2ade4e62a1038bdb23e0d5d573b675dd", null ],
    [ "awpDetectInPoint", "awp_detector_unit_8c.html#a86a98d4ed59aeeb7958dfe05190c45e7", null ],
    [ "awpDetectInRect2", "group__detectorgroup.html#gaa8bafc2bf2d369d55dbb05f9208363b3", null ],
    [ "awpFreeCascade", "group__detectorgroup.html#ga4bdffc836043eb1344462d42637e5cdf", null ],
    [ "awpInitCascade", "group__detectorgroup.html#ga963b9632a19eb94f8ca34e4944354250", null ],
    [ "awpLoadCascade", "group__detectorgroup.html#gaac7b70ff5f17008410db3535656e599e", null ],
    [ "awpObjectDetect", "group__detectorgroup.html#ga00cc0ec3b6d3d5a6c0654b4f5b3618f5", null ],
    [ "awpReleaseCascade", "group__detectorgroup.html#ga80cdaf2d69f4f2dfb0b851cd740e9ac0", null ],
    [ "CalcSum", "awp_detector_unit_8c.html#adf46043787b1c180d17c3ab627001d7d", null ],
    [ "GMCTDetector", "awp_detector_unit_8c.html#a83a9d04fcc6976789892d9bba923df63", null ]
];