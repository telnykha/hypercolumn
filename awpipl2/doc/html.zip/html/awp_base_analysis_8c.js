var awp_base_analysis_8c =
[
    [ "_AWP_BASE_ANALYSIS_CHECK_HST_", "awp_base_analysis_8c.html#ad12e9acfdec5dfd17e39a937ab785030", null ],
    [ "_AWP_BASE_ANALYSIS_CHECK_RESULT_", "awp_base_analysis_8c.html#a7b1bf63ece5000c500395b5eb9225666", null ],
    [ "_CALC_IDX_", "awp_base_analysis_8c.html#a51aba5337f1f230523c1d193f9c6cdfa", null ],
    [ "awpGet2DHistogramm", "group__histogroup.html#gafdd26019d69ce0b590e8fac37b66f48a", null ],
    [ "awpGetCentroid", "group__momemtsgroup.html#ga75f1d9deb52031940ee9f3085cb2f0aa", null ],
    [ "awpGetHst", "group__histogroup.html#gaa99bced186740a5de809a388efc26bf6", null ],
    [ "awpGetHstEntropy", "group__histogroup.html#ga3d3006d9b0a50e98ae57678574c98b52", null ],
    [ "awpGetHstMean", "group__histogroup.html#ga809b20b709feddc0a1784734e2a56073", null ],
    [ "awpGetHstStdDev", "group__histogroup.html#gad1cf71883daf682e33de2d5a07e9a84b", null ],
    [ "awpGetMedian", "group__histogroup.html#ga38b7c1656531b7020aa09de331f3d544", null ],
    [ "awpGetOrientation", "group__momemtsgroup.html#ga77ccc916bb8e36d7b984eb75912c3bad", null ],
    [ "awpHistogrammEqualize", "group__histogroup.html#gaa3420f175421009e0907a3abda1f47f1", null ]
];