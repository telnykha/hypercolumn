var structawp_camera =
[
    [ "dAngle", "structawp_camera.html#acbafd463d33a478f1b5a6b48adc4ff97", null ],
    [ "dChipHSize", "structawp_camera.html#a4a70b346197d3a75eeafff1922233688", null ],
    [ "dChipWSize", "structawp_camera.html#a17f603c0f9ac9392bba34d1823add0a7", null ],
    [ "dFocalLength", "structawp_camera.html#ab7678e06de0fb55328b43857f80ad27d", null ],
    [ "dHeight", "structawp_camera.html#ae96fbef0fed74f46369e8f67a9530d6a", null ],
    [ "dMaxLenght", "structawp_camera.html#a66216b5ca388fe58d058e3824a9cb735", null ]
];