var awp_color_8c =
[
    [ "mmax", "awp_color_8c.html#a9493c4e06606c94612e05c772d5c9b2a", null ],
    [ "mmin", "awp_color_8c.html#ad7cf61b6843c3ed06b7b1399d5e2fd21", null ],
    [ "SHIFT", "awp_color_8c.html#ac179eef68bcc694aa0ef8dd1eb09950b", null ],
    [ "awpHSLtoRGB", "group__convertgroup.html#gaec3c53a990d8aa8ea265096259a5c005", null ],
    [ "awpHSLtoRGBImage", "group__convertgroup.html#ga493cb89e4378df098512a84995ee4485", null ],
    [ "awpHSVtoRGB", "group__convertgroup.html#ga97aa4c848b7bffb48b511088991e1ebe", null ],
    [ "awpHSVtoRGBImage", "group__convertgroup.html#ga840a4ef439002b7e838952ee5a6d690b", null ],
    [ "awpLABtoRGB", "group__convertgroup.html#gaa16d0480d737b73c23e691bffd9cb880", null ],
    [ "awpRGBtoHSL", "group__convertgroup.html#gab9296dada721b6e341c3f01bb5f79b48", null ],
    [ "awpRGBtoHSLImage", "group__convertgroup.html#gaa7a316a2737aeb6f20db88e5f1f0515b", null ],
    [ "awpRGBtoHSV", "group__convertgroup.html#gad5854fa0f77101cac5926ef5c744e5cf", null ],
    [ "awpRGBtoHSVImage", "group__convertgroup.html#gaab7b4545d9e65b78ebfb60218a878f22", null ],
    [ "awpRGBtoLAB", "group__convertgroup.html#gaec0fd77ab9d5975bfbcc6cf03fc83969", null ],
    [ "awpRGBtoWeb", "group__convertgroup.html#ga4fcc23698ef60d269b1c97ad37c6ee42", null ],
    [ "awpRGBtoXYZ", "group__convertgroup.html#ga338f7e998ffb8a2311c73f4ff619c821", null ],
    [ "awpWebtoRGB", "group__convertgroup.html#ga8b8bc0d952f0b539af960b7a65177512", null ],
    [ "awpXYZtoRGB", "group__convertgroup.html#ga9cfae9dfe40b292031a1200782bafe38", null ]
];