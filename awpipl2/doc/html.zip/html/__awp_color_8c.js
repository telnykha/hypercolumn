var __awp_color_8c =
[
    [ "_AWP_NORM_RGB_", "__awp_color_8c.html#a52b50ac834c7ba3b733f30eae7f186c2", null ],
    [ "_awp_hsl_to_rgb", "__awp_color_8c.html#a241f5dda255158fceab1a47b42f7a7e2", null ],
    [ "_awp_hsv_to_rgb", "__awp_color_8c.html#a369a634410219ddb15fc4b58e636993a", null ],
    [ "_awp_lab_to_rgb", "__awp_color_8c.html#ab5225dbc12d298dac83e534109cdb106", null ],
    [ "_awp_lab_to_xyz", "__awp_color_8c.html#af1acf4b9ff7ec71eae0908a411ef475c", null ],
    [ "_awp_rgb_to_hsl", "__awp_color_8c.html#a21387344584fa3cfe4ae49d5c58dd7c8", null ],
    [ "_awp_rgb_to_hsv", "__awp_color_8c.html#a703787ee0001a8aa1a96efedb86f05f0", null ],
    [ "_awp_rgb_to_lab", "__awp_color_8c.html#ab407ed75c4090dcecb7f6e38bd5d07e6", null ],
    [ "_awp_rgb_to_xyz", "__awp_color_8c.html#aadf2c9539ecd119b051032aed05076a5", null ],
    [ "_awp_xyz_to_lab", "__awp_color_8c.html#ac170106df1adc4bd6e3799bb4906c35f", null ],
    [ "_awp_xyz_to_rgb", "__awp_color_8c.html#a40f76fa7310a39e5a0d95f9398551ea7", null ]
];