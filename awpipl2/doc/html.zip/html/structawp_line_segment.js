var structawp_line_segment =
[
    [ "end", "structawp_line_segment.html#a70fdfaaa38d8bc934d1d88368b7e855c", null ],
    [ "strat", "structawp_line_segment.html#a43a381bd72b9ef5b8875b171dc0467b5", null ]
];