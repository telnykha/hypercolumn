var awp_approx_8c =
[
    [ "_awpPolynomCalculate", "awp_approx_8c.html#af4f6c7dceb642e36f2682c91dfa430a2", null ],
    [ "awpApproxPoly", "group__approximation.html#ga7db806c738d044d22182a55573c1a2e7", null ]
];