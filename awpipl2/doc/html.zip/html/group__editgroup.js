var group__editgroup =
[
    [ "awpCopyImage", "group__editgroup.html#ga79ffb0b4a8fc08963fc5744216bb5358", null ],
    [ "awpCopyImageStr", "group__editgroup.html#ga6cfba8fb20d4dab7c38a7061680d8af6", null ],
    [ "awpCopyRect", "group__editgroup.html#gace05b28a1e5034746e4ea0d3bd7875f5", null ],
    [ "awpCopyRectSize", "group__editgroup.html#gae94dcd19c4262729b05df7f4f01cdb73", null ],
    [ "awpGetChannel", "group__editgroup.html#gaa7c16f2b9ddbc139ce39b61cd36f3cc0", null ],
    [ "awpPasteRect", "group__editgroup.html#ga5cdad14fe35ed09fd2e3a273c46c9e4b", null ],
    [ "awpPutChannel", "group__editgroup.html#gaa42281f0a9cf13377324ae7a6ec04bc9", null ]
];