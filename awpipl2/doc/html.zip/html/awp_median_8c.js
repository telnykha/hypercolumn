var awp_median_8c =
[
    [ "__awpMedian_double", "awp_median_8c.html#af200c4a0e072c72f3b06884a14d3a503", null ],
    [ "awpMedian", "group__arifgroup.html#ga8bb7b2dcb26b5ab18d4781ba3aa562b4", null ],
    [ "compare", "awp_median_8c.html#a915dbc22508ff5f397d37b9349ca4022", null ]
];