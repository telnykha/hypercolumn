var structawp_strong =
[
    [ "alfa", "structawp_strong.html#a8ecbe72863fa4bb064705c086230eac7", null ],
    [ "nWeaks", "structawp_strong.html#a411a2863be15771fb29beb862db0f4e1", null ],
    [ "pWeaks", "structawp_strong.html#acc8b064676d4d34f48efa0ac206996a4", null ]
];