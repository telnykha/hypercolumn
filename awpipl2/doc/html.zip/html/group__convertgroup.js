var group__convertgroup =
[
    [ "awpConvert", "group__convertgroup.html#ga78dc107138d184a0073bf14480cb0ea0", null ],
    [ "awpHSLtoRGB", "group__convertgroup.html#gaec3c53a990d8aa8ea265096259a5c005", null ],
    [ "awpHSLtoRGBImage", "group__convertgroup.html#ga493cb89e4378df098512a84995ee4485", null ],
    [ "awpHSVtoRGB", "group__convertgroup.html#ga97aa4c848b7bffb48b511088991e1ebe", null ],
    [ "awpHSVtoRGBImage", "group__convertgroup.html#ga840a4ef439002b7e838952ee5a6d690b", null ],
    [ "awpIntegral", "group__convertgroup.html#gaa39f4fa83798ba1b52c64d068aa23448", null ],
    [ "awpIntegral2", "group__convertgroup.html#ga5a51b4504e0293a20a65fab9f6beda3f", null ],
    [ "awpLABtoRGB", "group__convertgroup.html#gaa16d0480d737b73c23e691bffd9cb880", null ],
    [ "awpMakeBinary", "group__convertgroup.html#gaae88e6d9b105af3cd731ee3fb02b5d48", null ],
    [ "awpNorm", "group__convertgroup.html#ga88627d08f24e2086a728deff557cd0ef", null ],
    [ "awpNormalize", "group__convertgroup.html#ga8ab1f44f6d6dc75b437ead02d528be71", null ],
    [ "awpRGBtoHSL", "group__convertgroup.html#gab9296dada721b6e341c3f01bb5f79b48", null ],
    [ "awpRGBtoHSLImage", "group__convertgroup.html#gaa7a316a2737aeb6f20db88e5f1f0515b", null ],
    [ "awpRGBtoHSV", "group__convertgroup.html#gad5854fa0f77101cac5926ef5c744e5cf", null ],
    [ "awpRGBtoHSVImage", "group__convertgroup.html#gaab7b4545d9e65b78ebfb60218a878f22", null ],
    [ "awpRGBtoLAB", "group__convertgroup.html#gaec0fd77ab9d5975bfbcc6cf03fc83969", null ],
    [ "awpRGBtoWeb", "group__convertgroup.html#ga4fcc23698ef60d269b1c97ad37c6ee42", null ],
    [ "awpRGBtoXYZ", "group__convertgroup.html#ga338f7e998ffb8a2311c73f4ff619c821", null ],
    [ "awpWebtoRGB", "group__convertgroup.html#ga8b8bc0d952f0b539af960b7a65177512", null ],
    [ "awpXYZtoRGB", "group__convertgroup.html#ga9cfae9dfe40b292031a1200782bafe38", null ]
];