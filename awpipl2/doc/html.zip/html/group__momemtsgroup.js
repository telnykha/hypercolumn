var group__momemtsgroup =
[
    [ "awpGetCentroid", "group__momemtsgroup.html#ga75f1d9deb52031940ee9f3085cb2f0aa", null ],
    [ "awpGetOrientation", "group__momemtsgroup.html#ga77ccc916bb8e36d7b984eb75912c3bad", null ]
];