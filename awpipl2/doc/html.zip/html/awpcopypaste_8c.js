var awpcopypaste_8c =
[
    [ "SQR", "awpcopypaste_8c.html#ad41630f833e920c1ffa34722f45a8e77", null ],
    [ "awpCopyImage", "group__editgroup.html#ga79ffb0b4a8fc08963fc5744216bb5358", null ],
    [ "awpCopyImageStr", "group__editgroup.html#ga6cfba8fb20d4dab7c38a7061680d8af6", null ],
    [ "awpCopyRect", "group__editgroup.html#gace05b28a1e5034746e4ea0d3bd7875f5", null ],
    [ "awpCopyRectSize", "group__editgroup.html#gae94dcd19c4262729b05df7f4f01cdb73", null ],
    [ "awpFastCopyImage", "awpcopypaste_8c.html#a64261ae0fb81a3bafb490d09742dff59", null ],
    [ "awpFastIntegral", "awpcopypaste_8c.html#ac4bddaa0e5e6a7a7b433617f3ed2fed2", null ],
    [ "awpIntegral", "group__convertgroup.html#gaa39f4fa83798ba1b52c64d068aa23448", null ],
    [ "awpIntegral2", "group__convertgroup.html#ga5a51b4504e0293a20a65fab9f6beda3f", null ],
    [ "awpPasteRect", "group__editgroup.html#ga5cdad14fe35ed09fd2e3a273c46c9e4b", null ],
    [ "awpShlIntegral", "awpcopypaste_8c.html#a5ad9e73a6b029a7623e23e0728231b8b", null ]
];