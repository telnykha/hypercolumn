var structawp_cascade =
[
    [ "detectFunc", "structawp_cascade.html#a0957f16767e3d84988eadfe8bd63a033", null ],
    [ "detectorCascade", "structawp_cascade.html#a1b6d3fe7b5d783fcc256936e350b82b7", null ]
];