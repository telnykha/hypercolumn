var group__approximation =
[
    [ "awpApproxPoly", "group__approximation.html#ga7db806c738d044d22182a55573c1a2e7", null ]
];