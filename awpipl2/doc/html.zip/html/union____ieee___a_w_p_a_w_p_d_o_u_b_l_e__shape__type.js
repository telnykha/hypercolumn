var union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type =
[
    [ "__pad0__", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#ab94fdc200b1c71de281496e36b731acd", null ],
    [ "__pad1__", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a68aac251b5abe607e21114aaadf57bc5", null ],
    [ "data", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a400d52f1427f0ae88071ed2cb7fb0bcf", null ],
    [ "sign", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a789dfd00c6d3b259c2010c6ad13e0ed4", null ],
    [ "value", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a68431c05f6f2f3c6097cfe4168bed16e", null ]
];