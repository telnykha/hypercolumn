var awpframeprocess_8c =
[
    [ "awpAbsDiff", "group__arifgroup.html#gaecd626ef36b019e51a1ff4d0b880e6a4", null ],
    [ "awpCalcImage", "group__arifgroup.html#ga120d013d36c6445cabd1337928305f49", null ],
    [ "awpRunningAvg", "group__arifgroup.html#ga945381c384c3653501fa14d3c0c70c1a", null ]
];