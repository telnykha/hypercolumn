var structawp_spot_property =
[
    [ "Center", "structawp_spot_property.html#a13c80159c27ede24a715c8e643d98157", null ],
    [ "dM01", "structawp_spot_property.html#aa097fb7928e92e1c3ce34cfa20fff561", null ],
    [ "dM02", "structawp_spot_property.html#aec9d0ab08713e6843dc57571acb58a51", null ],
    [ "dM03", "structawp_spot_property.html#a0bc2d955280d7b183c8089713639642c", null ],
    [ "dM10", "structawp_spot_property.html#ac3ca39bb6ca99a18413935c0f2ec0e68", null ],
    [ "dM11", "structawp_spot_property.html#a6f2d3d679b6680e58e0a8a123ba5a8ac", null ],
    [ "dM12", "structawp_spot_property.html#a80a0348435821986112a87ff41bed855", null ],
    [ "dM20", "structawp_spot_property.html#a671b836b5166605d5f1debaebb59c836", null ],
    [ "dM21", "structawp_spot_property.html#a2f7f7f6c7820279dc38544fd2cdd8224", null ],
    [ "dM30", "structawp_spot_property.html#a4856fc1766533c721d36d960f1bf2395", null ],
    [ "flLx", "structawp_spot_property.html#a014c5299180420f85c45d1c8912503f9", null ],
    [ "flLy", "structawp_spot_property.html#a45c4e3ca5f5f3d4966e409f7083e033a", null ],
    [ "flMajor", "structawp_spot_property.html#a232857c0b092d5be5f5e955326354bfc", null ],
    [ "flMinor", "structawp_spot_property.html#a85555e1c8b7fbdd184bec774155d6a32", null ],
    [ "flPerim", "structawp_spot_property.html#aa0659179168c9de28513e6f62798913e", null ],
    [ "flSapeCoef", "structawp_spot_property.html#a0eeb94a5ab99e636d4432146e5825687", null ],
    [ "flSquare", "structawp_spot_property.html#aef676e04910be3e12f608d725c2c71b8", null ],
    [ "flTeta", "structawp_spot_property.html#ad2a07c7ca1fcb84b56cdc6ee6a0a7e36", null ],
    [ "Rect", "structawp_spot_property.html#a3aba352b767cdfc9431e9a966d0d24a2", null ]
];