var structawp_point =
[
    [ "X", "structawp_point.html#abf6cd6476233c7321c5bd582dff030eb", null ],
    [ "Y", "structawp_point.html#ac0927de57a2f66ac6918cf463da65ea5", null ]
];