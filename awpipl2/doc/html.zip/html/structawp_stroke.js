var structawp_stroke =
[
    [ "xl", "structawp_stroke.html#af33b9f0dda032613c40ebc1a160455e5", null ],
    [ "xr", "structawp_stroke.html#a1d16e691065d8e66c69cff11d09a9369", null ],
    [ "y", "structawp_stroke.html#ab8cde0d6d54371ee5ddde947b1ad47c2", null ]
];