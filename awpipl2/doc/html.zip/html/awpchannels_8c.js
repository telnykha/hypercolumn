var awpchannels_8c =
[
    [ "_AWP_GET_CHANNEL_", "awpchannels_8c.html#aba2c1dc242cb50656a2f503bccfeaad0", null ],
    [ "_AWP_PUT_CHANNEL_", "awpchannels_8c.html#af160d2568e82e9d47422e6a3c9dbe0f9", null ],
    [ "awpGetChannel", "group__editgroup.html#gaa7c16f2b9ddbc139ce39b61cd36f3cc0", null ],
    [ "awpGetChannel2", "awpchannels_8c.html#a2a774e30dfaf75949aa67d5608d6d747", null ],
    [ "awpPutChannel", "group__editgroup.html#gaa42281f0a9cf13377324ae7a6ec04bc9", null ]
];