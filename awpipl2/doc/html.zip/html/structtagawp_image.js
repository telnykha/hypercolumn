var structtagawp_image =
[
    [ "bChannels", "structtagawp_image.html#abfb595f2de639d6f79a420570e9a3d81", null ],
    [ "dwType", "structtagawp_image.html#a258cf27f59f541d252d87e99faeda695", null ],
    [ "nMagic", "structtagawp_image.html#a9b4996762f971dca8ea8f76bc6f9d7b7", null ],
    [ "pPixels", "structtagawp_image.html#a8456a817c580bac3165bd2b30d45267c", null ],
    [ "sSizeX", "structtagawp_image.html#aa54e3d1b13100918e41e99e0917faf4f", null ],
    [ "sSizeY", "structtagawp_image.html#af13c55c16a3d1740e06410dea90bdda2", null ]
];