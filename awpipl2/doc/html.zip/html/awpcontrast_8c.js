var awpcontrast_8c =
[
    [ "__ieee_AWPAWPDOUBLE_shape_type", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html", "union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type" ],
    [ "awpAutoLevels", "group__arifgroup.html#ga8469307a9fc5eabc52a1fc0ceb961708", null ],
    [ "awpBilinearBlur", "awpcontrast_8c.html#a9e4cc93a7953e3fadabe57f1136325b9", null ],
    [ "awpDispercy", "awpcontrast_8c.html#ab753b77fedf1f4df93624c97eb501163", null ],
    [ "awpNormalizeAdaptive", "awpcontrast_8c.html#a2e95a03c21b291ceecfe08a71782f2fc", null ]
];