var group__histogroup =
[
    [ "awpBackProjection2D", "group__histogroup.html#ga0203ad2cdee55ebd1ffd3beb4a8eb962", null ],
    [ "awpGet2DHistogramm", "group__histogroup.html#gafdd26019d69ce0b590e8fac37b66f48a", null ],
    [ "awpGetHst", "group__histogroup.html#gaa99bced186740a5de809a388efc26bf6", null ],
    [ "awpGetHstEntropy", "group__histogroup.html#ga3d3006d9b0a50e98ae57678574c98b52", null ],
    [ "awpGetHstMean", "group__histogroup.html#ga809b20b709feddc0a1784734e2a56073", null ],
    [ "awpGetHstStdDev", "group__histogroup.html#gad1cf71883daf682e33de2d5a07e9a84b", null ],
    [ "awpGetMedian", "group__histogroup.html#ga38b7c1656531b7020aa09de331f3d544", null ],
    [ "awpHistogrammEqualize", "group__histogroup.html#gaa3420f175421009e0907a3abda1f47f1", null ]
];