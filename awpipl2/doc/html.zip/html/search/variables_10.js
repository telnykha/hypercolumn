var searchData=
[
  ['top_1132',['top',['../structawp_rect.html#a6123ab49903fa86f1f9c0d7a742717a6',1,'awpRect']]],
  ['type_1133',['type',['../structawp_detector.html#ac32238f9c92e69700ff2c2a0b2d92d7e',1,'awpDetector']]]
];
