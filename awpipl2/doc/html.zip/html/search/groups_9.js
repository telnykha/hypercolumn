var searchData=
[
  ['object_20detection_20related_20functions_1349',['Object detection related functions',['../group__detectorgroup.html',1,'']]]
];
