var searchData=
[
  ['moments_20related_20functions_1348',['Moments related functions',['../group__momemtsgroup.html',1,'']]]
];
