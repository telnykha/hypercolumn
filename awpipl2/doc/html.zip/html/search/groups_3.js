var searchData=
[
  ['edge_20functions_1341',['Edge functions',['../group__edgegroup.html',1,'']]]
];
