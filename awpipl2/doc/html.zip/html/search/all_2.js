var searchData=
[
  ['baseheight_504',['baseHeight',['../structawp_scanner.html#a5ce6f94a4e7736b882046edbc8b1b3b9',1,'awpScanner']]],
  ['basewidth_505',['baseWidth',['../structawp_scanner.html#a035207a9a8202e4cccceb5ad4f9358f9',1,'awpScanner']]],
  ['bblue_506',['bBlue',['../structtagawp_color.html#aabc4e03bafc1a959db6912e4fb7e4450',1,'tagawpColor::bBlue()'],['../structtagawp_r_g_b_color.html#aabc4e03bafc1a959db6912e4fb7e4450',1,'tagawpRGBColor::bBlue()'],['../structtag_old_awp_color.html#aabc4e03bafc1a959db6912e4fb7e4450',1,'tagOldAwpColor::bBlue()']]],
  ['bchannels_507',['bChannels',['../structtagawp_image.html#abfb595f2de639d6f79a420570e9a3d81',1,'tagawpImage']]],
  ['bgreen_508',['bGreen',['../structtagawp_color.html#a9cbb3177c39dadc446e08b8137605a59',1,'tagawpColor::bGreen()'],['../structtagawp_r_g_b_color.html#a9cbb3177c39dadc446e08b8137605a59',1,'tagawpRGBColor::bGreen()'],['../structtag_old_awp_color.html#a9cbb3177c39dadc446e08b8137605a59',1,'tagOldAwpColor::bGreen()']]],
  ['bins_509',['bins',['../structawp_weak.html#a87ff0ad38ad2839fa6352ef1893e6ab5',1,'awpWeak']]],
  ['bottom_510',['bottom',['../structawp_rect.html#aa44ae661c06fe6fe9ab4817d046ca9bc',1,'awpRect']]],
  ['bred_511',['bRed',['../structtagawp_color.html#a7361ba4cd819bc0902925a6e57dee451',1,'tagawpColor::bRed()'],['../structtagawp_r_g_b_color.html#a7361ba4cd819bc0902925a6e57dee451',1,'tagawpRGBColor::bRed()'],['../structtag_old_awp_color.html#a7361ba4cd819bc0902925a6e57dee451',1,'tagOldAwpColor::bRed()']]]
];
