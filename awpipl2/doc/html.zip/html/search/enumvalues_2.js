var searchData=
[
  ['drr_1167',['dRR',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfaa1dbf0d312d3b13b9a86b2fc8b76510e',1,'awpstroke.c']]]
];
