var searchData=
[
  ['mmax_1327',['mmax',['../awp_color_8c.html#a9493c4e06606c94612e05c772d5c9b2a',1,'awpColor.c']]],
  ['mmin_1328',['mmin',['../awp_color_8c.html#ad7cf61b6843c3ed06b7b1399d5e2fd21',1,'awpColor.c']]]
];
