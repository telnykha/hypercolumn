var searchData=
[
  ['ownexchangestr_1025',['ownExchangeStr',['../awpstroke_8c.html#add645baa33044541c1fe9d5e082c8fe4',1,'awpstroke.c']]]
];
