var searchData=
[
  ['single_20camera_20geometry_20functions_647',['Single camera geometry functions',['../group__cameragroup.html',1,'']]],
  ['scalescanner_648',['ScaleScanner',['../group__datastructures.html#gga01414cf461d16f33bbd7d6b9d9ee500baf70c15947d6f60b1e8635d46cef69a5a',1,'awpipl.h']]],
  ['scalestep_649',['scaleStep',['../structawp_scanner.html#a6f35b366f6c4584159dc45422902d5a7',1,'awpScanner']]],
  ['scannertype_650',['scannerType',['../structawp_scanner.html#ae863eabbc239e5178104fd6dc5c699e6',1,'awpScanner']]],
  ['sd_651',['sD',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfaf4f5a6fa01b43c881a89ca24792351f9',1,'awpstroke.c']]],
  ['shift_652',['Shift',['../structawp_detect_item.html#ab1667870188ddcdfd1b4a46da807aa30',1,'awpDetectItem::Shift()'],['../awp_color_8c.html#ac179eef68bcc694aa0ef8dd1eb09950b',1,'SHIFT():&#160;awpColor.c']]],
  ['sign_653',['sign',['../union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a789dfd00c6d3b259c2010c6ad13e0ed4',1,'__ieee_AWPAWPDOUBLE_shape_type']]],
  ['size_654',['size',['../structawp_quadrangle.html#a7c508e4aa69a489a7b566eec600afd82',1,'awpQuadrangle']]],
  ['slr_655',['sLR',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfa12062a72cdf38b022e09fcffe8a597f1',1,'awpstroke.c']]],
  ['sqr_656',['SQR',['../awpcopypaste_8c.html#ad41630f833e920c1ffa34722f45a8e77',1,'awpcopypaste.c']]],
  ['srl_657',['sRL',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfab0a775b71ace21e099ed42b176b8ad22',1,'awpstroke.c']]],
  ['ssizex_658',['sSizeX',['../structtagawp_image.html#aa54e3d1b13100918e41e99e0917faf4f',1,'tagawpImage']]],
  ['ssizey_659',['sSizeY',['../structtagawp_image.html#af13c55c16a3d1740e06410dea90bdda2',1,'tagawpImage']]],
  ['stat_660',['Stat',['../awpmain_8c.html#a0a3ee7811501c9aa5b5de8393158c668',1,'awpmain.c']]],
  ['stepdistance_661',['stepDistance',['../structawp_scanner.html#a574a648eb2639e5a644b20e2a6a435cd',1,'awpScanner']]],
  ['stepgranularity_662',['stepGranularity',['../structawp_scanner.html#a84c0d042626c96fd5457ec6512ea94bd',1,'awpScanner']]],
  ['stepheight_663',['stepHeight',['../structawp_scanner.html#a1832cff847e32b6466c3a2ab53aefb8d',1,'awpScanner']]],
  ['stepshift_664',['stepShift',['../structawp_scanner.html#a765b64c4299a7e2d65e90439e95d8137',1,'awpScanner']]],
  ['strat_665',['strat',['../structawp_line_segment.html#a43a381bd72b9ef5b8875b171dc0467b5',1,'awpLineSegment::strat()'],['../structawp2_d_line_segment.html#a25c9c57721b69b4404dc88a14a56f119',1,'awp2DLineSegment::strat()']]],
  ['strokes_20function_666',['Strokes function',['../group__strokegroup.html',1,'']]],
  ['strokes_667',['strokes',['../structawp_stroke_obj.html#a3de64ad7b72b5bba78f0e77c6fff9b1b',1,'awpStrokeObj']]]
];
