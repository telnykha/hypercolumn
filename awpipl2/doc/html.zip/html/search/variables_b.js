var searchData=
[
  ['nmagic_1101',['nMagic',['../structtagawp_image.html#a9b4996762f971dca8ea8f76bc6f9d7b7',1,'tagawpImage']]],
  ['nstages_1102',['nStages',['../structawp_detector.html#aca4fdd4bcc3799930032658aad1b6097',1,'awpDetector']]],
  ['num_1103',['Num',['../structawp_stroke_obj.html#aea0de675fce48032419164e1ee46a2f3',1,'awpStrokeObj']]],
  ['numbins_1104',['numBins',['../structawp_weak.html#a515b0aa3c5977d9629890d0b6ae90564',1,'awpWeak']]],
  ['numpoints_1105',['NumPoints',['../structawp_contour.html#a7848403591387b703285a38ecc77af79',1,'awpContour::NumPoints()'],['../structawp2_d_contour.html#a7848403591387b703285a38ecc77af79',1,'awp2DContour::NumPoints()']]],
  ['nweaks_1106',['nWeaks',['../structawp_strong.html#a411a2863be15771fb29beb862db0f4e1',1,'awpStrong']]]
];
