var searchData=
[
  ['ownnearstdef_709',['ownNearStDef',['../structown_near_st_def.html',1,'']]],
  ['ownstrokeattrdef_710',['ownStrokeAttrDef',['../structown_stroke_attr_def.html',1,'']]]
];
