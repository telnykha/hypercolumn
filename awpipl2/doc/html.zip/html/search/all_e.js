var searchData=
[
  ['points_631',['Points',['../structawp_contour.html#aa350bec96a232902cf57c2212aa0c98c',1,'awpContour::Points()'],['../structawp2_d_contour.html#a6826bab75e3b45109c8c257d229bb57b',1,'awp2DContour::Points()']]],
  ['ppixels_632',['pPixels',['../structtagawp_image.html#a8456a817c580bac3165bd2b30d45267c',1,'tagawpImage']]],
  ['pstrongs_633',['pStrongs',['../structawp_detector.html#af0beec86bd78700ea4b41587234c33ca',1,'awpDetector']]],
  ['pweaks_634',['pWeaks',['../structawp_strong.html#acc8b064676d4d34f48efa0ac206996a4',1,'awpStrong']]]
];
