var searchData=
[
  ['r_635',['r',['../structcawp_rect.html#a17da818e4c99f7e0e44ea0e714e8effe',1,'cawpRect::r()'],['../structcawp_detect_item.html#a2a69951e2f2a601ea66fac58ca54551e',1,'cawpDetectItem::r()']]],
  ['r_5fattr_636',['r_attr',['../structown_stroke_attr_def.html#a432c05fafa5adc7031aae70a126c99e1',1,'ownStrokeAttrDef']]],
  ['r_5findex_637',['r_index',['../structown_stroke_attr_def.html#ad396cf82e53a0fee056abdd1b710603a',1,'ownStrokeAttrDef']]],
  ['readme_2emd_638',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rect_639',['Rect',['../structawp_spot_property.html#a3aba352b767cdfc9431e9a966d0d24a2',1,'awpSpotProperty::Rect()'],['../structawp_detect_item.html#ab98e6b08edc24be5b1970dee24fe4e43',1,'awpDetectItem::rect()']]],
  ['rescale_640',['Rescale',['../awpmain_8c.html#a3cc5fd7abe136abdf80ed9e2cee18381',1,'awpmain.c']]],
  ['resize_641',['Resize',['../awpmain_8c.html#a325bca9712945c612a4c0fe4bc6d0f62',1,'awpmain.c']]],
  ['right_642',['right',['../structawp_rect.html#a8aa98195f3b4eead522fd49c3fef2c16',1,'awpRect']]],
  ['right_5fbottom_643',['right_bottom',['../structawp_quadrangle.html#a834cef3f7222d4e5538db8a31393cd7a',1,'awpQuadrangle']]],
  ['right_5ftop_644',['right_top',['../structawp_quadrangle.html#a504fea1f3af9567addcaae02b8149ed6',1,'awpQuadrangle']]],
  ['rotate_645',['Rotate',['../awpmain_8c.html#af34e75e52322cda796ed58f2e03ef069',1,'awpmain.c']]],
  ['rotatecenter_646',['RotateCenter',['../awpmain_8c.html#a4c0cd1e256db220cb1b784bb4f67be2f',1,'awpmain.c']]]
];
