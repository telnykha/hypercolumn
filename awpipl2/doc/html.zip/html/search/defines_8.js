var searchData=
[
  ['shift_1330',['SHIFT',['../awp_color_8c.html#ac179eef68bcc694aa0ef8dd1eb09950b',1,'awpColor.c']]],
  ['sqr_1331',['SQR',['../awpcopypaste_8c.html#ad41630f833e920c1ffa34722f45a8e77',1,'awpcopypaste.c']]]
];
