var searchData=
[
  ['approximation_1333',['Approximation',['../group__approximation.html',1,'']]],
  ['arithmetic_20and_20logical_20operations_1334',['Arithmetic and logical operations',['../group__arifgroup.html',1,'']]]
];
