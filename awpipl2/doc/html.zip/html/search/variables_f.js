var searchData=
[
  ['scalestep_1119',['scaleStep',['../structawp_scanner.html#a6f35b366f6c4584159dc45422902d5a7',1,'awpScanner']]],
  ['scannertype_1120',['scannerType',['../structawp_scanner.html#ae863eabbc239e5178104fd6dc5c699e6',1,'awpScanner']]],
  ['shift_1121',['Shift',['../structawp_detect_item.html#ab1667870188ddcdfd1b4a46da807aa30',1,'awpDetectItem']]],
  ['sign_1122',['sign',['../union____ieee___a_w_p_a_w_p_d_o_u_b_l_e__shape__type.html#a789dfd00c6d3b259c2010c6ad13e0ed4',1,'__ieee_AWPAWPDOUBLE_shape_type']]],
  ['size_1123',['size',['../structawp_quadrangle.html#a7c508e4aa69a489a7b566eec600afd82',1,'awpQuadrangle']]],
  ['ssizex_1124',['sSizeX',['../structtagawp_image.html#aa54e3d1b13100918e41e99e0917faf4f',1,'tagawpImage']]],
  ['ssizey_1125',['sSizeY',['../structtagawp_image.html#af13c55c16a3d1740e06410dea90bdda2',1,'tagawpImage']]],
  ['stepdistance_1126',['stepDistance',['../structawp_scanner.html#a574a648eb2639e5a644b20e2a6a435cd',1,'awpScanner']]],
  ['stepgranularity_1127',['stepGranularity',['../structawp_scanner.html#a84c0d042626c96fd5457ec6512ea94bd',1,'awpScanner']]],
  ['stepheight_1128',['stepHeight',['../structawp_scanner.html#a1832cff847e32b6466c3a2ab53aefb8d',1,'awpScanner']]],
  ['stepshift_1129',['stepShift',['../structawp_scanner.html#a765b64c4299a7e2d65e90439e95d8137',1,'awpScanner']]],
  ['strat_1130',['strat',['../structawp_line_segment.html#a43a381bd72b9ef5b8875b171dc0467b5',1,'awpLineSegment::strat()'],['../structawp2_d_line_segment.html#a25c9c57721b69b4404dc88a14a56f119',1,'awp2DLineSegment::strat()']]],
  ['strokes_1131',['strokes',['../structawp_stroke_obj.html#a3de64ad7b72b5bba78f0e77c6fff9b1b',1,'awpStrokeObj']]]
];
