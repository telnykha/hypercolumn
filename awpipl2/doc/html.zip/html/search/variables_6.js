var searchData=
[
  ['fllx_1073',['flLx',['../structawp_spot_property.html#a014c5299180420f85c45d1c8912503f9',1,'awpSpotProperty']]],
  ['flly_1074',['flLy',['../structawp_spot_property.html#a45c4e3ca5f5f3d4966e409f7083e033a',1,'awpSpotProperty']]],
  ['flmajor_1075',['flMajor',['../structawp_spot_property.html#a232857c0b092d5be5f5e955326354bfc',1,'awpSpotProperty']]],
  ['flminor_1076',['flMinor',['../structawp_spot_property.html#a85555e1c8b7fbdd184bec774155d6a32',1,'awpSpotProperty']]],
  ['flperim_1077',['flPerim',['../structawp_spot_property.html#aa0659179168c9de28513e6f62798913e',1,'awpSpotProperty']]],
  ['flsapecoef_1078',['flSapeCoef',['../structawp_spot_property.html#a0eeb94a5ab99e636d4432146e5825687',1,'awpSpotProperty']]],
  ['flsquare_1079',['flSquare',['../structawp_spot_property.html#aef676e04910be3e12f608d725c2c71b8',1,'awpSpotProperty']]],
  ['flteta_1080',['flTeta',['../structawp_spot_property.html#ad2a07c7ca1fcb84b56cdc6ee6a0a7e36',1,'awpSpotProperty']]]
];
