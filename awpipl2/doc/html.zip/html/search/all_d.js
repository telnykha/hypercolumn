var searchData=
[
  ['object_20detection_20related_20functions_621',['Object detection related functions',['../group__detectorgroup.html',1,'']]],
  ['oldawpcolor_622',['OldAwpColor',['../__awpio_8c.html#aa20ad2bf0cea770f7a5207ce24bcc441',1,'_awpio.c']]],
  ['overlap_623',['overlap',['../structawp_detect_item.html#a16a6938451038fd9a31de8f1313150b9',1,'awpDetectItem']]],
  ['owneattr_624',['ownEAttr',['../awpstroke_8c.html#a4fc08fd544ec013cefd7baba2e21a571',1,'awpstroke.c']]],
  ['owneattrdef_625',['ownEAttrDef',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbf',1,'awpstroke.c']]],
  ['ownexchangestr_626',['ownExchangeStr',['../awpstroke_8c.html#add645baa33044541c1fe9d5e082c8fe4',1,'awpstroke.c']]],
  ['ownnearst_627',['ownNearSt',['../awpstroke_8c.html#a758739373f26c10904562f0439347957',1,'awpstroke.c']]],
  ['ownnearstdef_628',['ownNearStDef',['../structown_near_st_def.html',1,'']]],
  ['ownstrokeattr_629',['ownStrokeAttr',['../awpstroke_8c.html#ad4e599c59960e0a08b063d9c54bb8376',1,'awpstroke.c']]],
  ['ownstrokeattrdef_630',['ownStrokeAttrDef',['../structown_stroke_attr_def.html',1,'']]]
];
