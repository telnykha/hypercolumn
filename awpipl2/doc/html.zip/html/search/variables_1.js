var searchData=
[
  ['alfa_1033',['alfa',['../structawp_weak.html#a8ecbe72863fa4bb064705c086230eac7',1,'awpWeak::alfa()'],['../structawp_strong.html#a8ecbe72863fa4bb064705c086230eac7',1,'awpStrong::alfa()']]]
];
