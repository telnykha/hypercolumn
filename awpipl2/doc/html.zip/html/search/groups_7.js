var searchData=
[
  ['loacal_20binary_20pattens_1347',['Loacal Binary Pattens',['../group__awplbbgroup.html',1,'']]]
];
