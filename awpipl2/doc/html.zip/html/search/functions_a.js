var searchData=
[
  ['rescale_1026',['Rescale',['../awpmain_8c.html#a3cc5fd7abe136abdf80ed9e2cee18381',1,'awpmain.c']]],
  ['resize_1027',['Resize',['../awpmain_8c.html#a325bca9712945c612a4c0fe4bc6d0f62',1,'awpmain.c']]],
  ['rotate_1028',['Rotate',['../awpmain_8c.html#af34e75e52322cda796ed58f2e03ef069',1,'awpmain.c']]],
  ['rotatecenter_1029',['RotateCenter',['../awpmain_8c.html#a4c0cd1e256db220cb1b784bb4f67be2f',1,'awpmain.c']]]
];
