var searchData=
[
  ['nlr_611',['nLR',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfad94389f4d5e4e0bc63cc0cfd9cf697a8',1,'awpstroke.c']]],
  ['nmagic_612',['nMagic',['../structtagawp_image.html#a9b4996762f971dca8ea8f76bc6f9d7b7',1,'tagawpImage']]],
  ['nrl_613',['nRL',['../awpstroke_8c.html#a6dedd8ccb068d5b9bf292a7a53c11fbfa391bc33b270fea89b5faf4d04bc7e21a',1,'awpstroke.c']]],
  ['nstages_614',['nStages',['../structawp_detector.html#aca4fdd4bcc3799930032658aad1b6097',1,'awpDetector']]],
  ['null_615',['NULL',['../awpipl_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'awpipl.h']]],
  ['nullscanner_616',['NullScanner',['../group__datastructures.html#gga01414cf461d16f33bbd7d6b9d9ee500bab49ee1313e0056bcaa7f5a7e712962ab',1,'awpipl.h']]],
  ['num_617',['Num',['../structawp_stroke_obj.html#aea0de675fce48032419164e1ee46a2f3',1,'awpStrokeObj']]],
  ['numbins_618',['numBins',['../structawp_weak.html#a515b0aa3c5977d9629890d0b6ae90564',1,'awpWeak']]],
  ['numpoints_619',['NumPoints',['../structawp_contour.html#a7848403591387b703285a38ecc77af79',1,'awpContour::NumPoints()'],['../structawp2_d_contour.html#a7848403591387b703285a38ecc77af79',1,'awp2DContour::NumPoints()']]],
  ['nweaks_620',['nWeaks',['../structawp_strong.html#a411a2863be15771fb29beb862db0f4e1',1,'awpStrong']]]
];
