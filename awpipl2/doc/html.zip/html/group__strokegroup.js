var group__strokegroup =
[
    [ "awpCalcObjRect", "group__strokegroup.html#gac5bbbbfb0ecaa95d5ab0f02fcdf201bc", null ],
    [ "awpCopyStrokeObj1", "group__strokegroup.html#ga0cd6656d250704140b3856be5d51b7c8", null ],
    [ "awpDrawColorStrokeObj", "group__strokegroup.html#ga419d11ed8f8e5f907fd0b8201b2a1d38", null ],
    [ "awpDrawStrokeObj", "group__strokegroup.html#ga4a2a791678f47d00a17b202ca3a280e7", null ],
    [ "awpDrawStrokes", "group__strokegroup.html#ga780fa5eb2b559228ac7dcb3f443a85ba", null ],
    [ "awpFreeStrokes", "group__strokegroup.html#gab61917c6753d8e5ecefa13c6258316d9", null ],
    [ "awpGetObjCentroid", "group__strokegroup.html#ga0022b832c3b9883870a34e12af9ff284", null ],
    [ "awpGetObjCountour", "group__strokegroup.html#gad509cddeb7ba151d039e15a6bb6cfd7c", null ],
    [ "awpGetObjIntensity", "group__strokegroup.html#ga9166f568bb115687c3b9c1627f3c86ad", null ],
    [ "awpGetObjMoment", "group__strokegroup.html#ga0d3707427ed5c273e94b532994e74cee", null ],
    [ "awpGetObjOrientation", "group__strokegroup.html#ga753feac9eaf698a8f19e55b0d07f11d8", null ],
    [ "awpGetObjPoint", "group__strokegroup.html#ga654de846ba4b884d4169c3e86033e990", null ],
    [ "awpGetObjTotalIntensity", "group__strokegroup.html#gaef4228c49510feb791fb2a7303aeb6c2", null ],
    [ "awpGetStrokes", "group__strokegroup.html#ga50ea886cbf35f8118b4f5f32cad2ce7e", null ],
    [ "awpStrObjSquare", "group__strokegroup.html#ga579ee5611ea6c3e162af1a69df239e84", null ]
];