var group__detectorgroup =
[
    [ "awpClusterFound", "group__detectorgroup.html#gac6ee5e85a1f30e2fe3b79c7a8a8a2556", null ],
    [ "awpCreateCascade", "group__detectorgroup.html#ga2ade4e62a1038bdb23e0d5d573b675dd", null ],
    [ "awpDetectInRect", "group__detectorgroup.html#ga7f3ae301aa75ffab795dc6e6ac1e0d67", null ],
    [ "awpDetectInRect2", "group__detectorgroup.html#gaa8bafc2bf2d369d55dbb05f9208363b3", null ],
    [ "awpExteractFound", "group__detectorgroup.html#ga9f9d42771a64ef69a6f95e3ffc711fc5", null ],
    [ "awpFreeCascade", "group__detectorgroup.html#ga4bdffc836043eb1344462d42637e5cdf", null ],
    [ "awpInitCascade", "group__detectorgroup.html#ga963b9632a19eb94f8ca34e4944354250", null ],
    [ "awpLoadCascade", "group__detectorgroup.html#gaac7b70ff5f17008410db3535656e599e", null ],
    [ "awpObjectDetect", "group__detectorgroup.html#ga00cc0ec3b6d3d5a6c0654b4f5b3618f5", null ],
    [ "awpReleaseCascade", "group__detectorgroup.html#ga80cdaf2d69f4f2dfb0b851cd740e9ac0", null ],
    [ "awpScanImage", "group__detectorgroup.html#ga6864a8dae799d27a670e3ae50163de47", null ]
];