var structawp_quadrangle =
[
    [ "left_bottom", "structawp_quadrangle.html#a164b7b55fa13725c58540293e3288704", null ],
    [ "left_top", "structawp_quadrangle.html#ae5130361dbc094a0b22470e4156560f1", null ],
    [ "right_bottom", "structawp_quadrangle.html#a834cef3f7222d4e5538db8a31393cd7a", null ],
    [ "right_top", "structawp_quadrangle.html#a504fea1f3af9567addcaae02b8149ed6", null ],
    [ "size", "structawp_quadrangle.html#a7c508e4aa69a489a7b566eec600afd82", null ]
];